import streamlit as st
import pandas as pd
import plotly.express as px

def DataFrame():
    df = pd.read_excel('df_clean.xlsx')
    df_jan = df[df['mes'] == 1].round(2).drop(columns='Unnamed: 0')
    df_fev = df[df['mes'] == 2].round(2).drop(columns='Unnamed: 0')
    df_mar = df[df['mes'] == 3].round(2).drop(columns='Unnamed: 0')
    df_abr = df[df['mes'] == 4].round(2).drop(columns='Unnamed: 0')
    df_mai = df[df['mes'] == 5].round(2).drop(columns='Unnamed: 0')
    # df_jun =  df[df['mes'] == 6].round(2).drop(columns='Unnamed: 0')
    # df_jul =  df[df['mes'] == 7].round(2).drop(columns='Unnamed: 0')
    # df_ago =  df[df['mes'] == 8].round(2).drop(columns='Unnamed: 0')
    # df_set =  df[df['mes'] == 9].round(2).drop(columns='Unnamed: 0')
    # df_out =  df[df['mes'] == 10].round(2).drop(columns='Unnamed: 0')
    # df_nov =  df[df['mes'] == 11].round(2).drop(columns='Unnamed: 0')
    # df_dez =  df[df['mes'] == 12].round(2).drop(columns='Unnamed: 0')

    st.write(df_jan)
    st.dataframe(df_fev)
    st.table(df_mar)
    st.table(df_abr)
    st.table(df_mai)