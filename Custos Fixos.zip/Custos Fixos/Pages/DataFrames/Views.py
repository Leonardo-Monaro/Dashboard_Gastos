import streamlit as st
import pandas as pd
from plotly.subplots import make_subplots
import plotly.graph_objects as go

def Views():
    df = pd.read_excel('df_clean.xlsx')
    df_jan = df[df['mes'] == 1].round(2).drop(columns='Unnamed: 0')
    df_fev = df[df['mes'] == 2].round(2).drop(columns='Unnamed: 0')
    df_mar = df[df['mes'] == 3].round(2).drop(columns='Unnamed: 0')
    df_abr = df[df['mes'] == 4].round(2).drop(columns='Unnamed: 0')
    df_mai = df[df['mes'] == 5].round(2).drop(columns='Unnamed: 0')

    fig = make_subplots(rows=6, cols=1)

    charts = fig.add_trace(
        go.Bar(
            x=df_jan['categoria_grupo'], 
            y=df_jan['valor'], 
            text=df_jan['valor'], 
            textposition='auto', 
            name='JANEIRO'),  
            row=1, col=1
            )

    fig.add_trace(
        go.Bar(
            x=df_fev['categoria_grupo'], 
            y=df_fev['valor'], 
            text=df_fev['valor'], 
            textposition='auto', 
            name='FEVEREIRO'), 
            row=2, col=1
            )

    fig.add_trace(
        go.Bar(
            x=df_mar['categoria_grupo'], 
            y=df_mar['valor'], 
            text=df_mar['valor'], 
            textposition='auto', 
            name='MARÇO'), 
            row=3, col=1
            )

    fig.add_trace(
        go.Bar(
            x=df_abr['categoria_grupo'], 
            y=df_abr['valor'], 
            text=df_abr['valor'], 
            textposition='auto', 
            name='ABRIL'), 
            row=4, col=1
            )

    fig.add_trace(
        go.Bar(
            x=df_mai['categoria_grupo'], 
            y=df_mai['valor'], 
            text=df_mai['valor'], 
            textposition='auto', 
            name='MAIO'), 
            row=5, col=1
            )

    fig.update_layout(height=2000, width=1300)

    st.plotly_chart(charts)
