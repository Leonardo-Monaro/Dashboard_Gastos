# Libs
import streamlit as st
import pandas as pd
import plotly.express as px

# Dados de exemplo
data = pd.read_excel(r'C:\Users\L8358814\Desktop\Custos Fixos\analise_custos_fixos.xlsx', sheet_name='Analise')
df = pd.DataFrame(data)

# Função para tratamento da base de dados
def tratamento(df):
    df.rename(columns={'Período contábil':'mes',
              'Data de lançamento':'data_lcto',
              'Em moeda de contabilização':'valor',
              'Categoria Grupo':'categoria_grupo',
              'Grupos Gastos':'grupo_gastos'}, inplace = True)
    return df

# Função para renomear colunas originais do dataframe
df_filter = df.drop(columns=['Empresa recept.', 
                 'Centro',
                 'Divisão', 
                 'Centro custo', 
                 'Nº conta', 
                 'Denominação',
                 'Nº documento', 
                 'Classe de objetos',
                 'Cliente', 
                 'Documento de compras', 
                 'Documento de vendas', 
                 'Material',
                 'Quantidade',
                 'Tipo de documento'])

# Aplicando função no dataframe
df_filter = tratamento(df_filter)
df_filter

# Criando agrupamento das colunas para ver os resultados por mês
df_result = df_filter.groupby(['mes','categoria_grupo'])['valor'].sum().reset_index()
df_result

fig = px.bar(df_result, 
             x='categoria_grupo', 
             y='valor', 
             color='categoria_grupo', 
             title='Soma dos valores por mês e categoria')
st.plotly_chart(fig)