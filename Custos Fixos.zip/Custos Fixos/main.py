# Libs
import streamlit as st
import pandas as pd
import plotly.express as px
import Pages.DataFrames.DFs as PagesDataFramesDFs
import Pages.DataFrames.Views as PagesDataFramesViews

st.title('GASTOS FIXOS BRASILIT')

st.sidebar.title('Acompanhamento Gastos Fixos')

Main_page = st.sidebar.selectbox(
    'Selecione', ['Tabelas Grupos GR55', 'Visualizações Mensais Grupos']
)

if Main_page == 'Tabelas Grupos GR55':
    PagesDataFramesDFs.DataFrame()


if Main_page == 'Visualizações Mensais Grupos':
    PagesDataFramesViews.Views()